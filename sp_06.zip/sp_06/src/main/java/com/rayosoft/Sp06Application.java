package com.rayosoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp06Application {

	public static void main(String[] args) {
		SpringApplication.run(Sp06Application.class, args);
	}

}
