package com.fabian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScottSpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScottSpApplication.class, args);
	}

}
