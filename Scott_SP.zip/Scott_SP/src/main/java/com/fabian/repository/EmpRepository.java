package com.fabian.repository;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.fabian.model.Emp;

public interface EmpRepository extends JpaRepository<Emp, Integer> {

    List<Emp> findByJob(String job);

    List<Emp> findBySalGreaterThan(Float salario);

    Page<Emp> findByDept_Deptno(Integer deptno, Pageable page);

    @Modifying
    @Transactional
    @Query("UPDATE Emp e SET e.sal = e.sal * :porcentaje WHERE e.empno = :idEmpleado")
    void aumentarSalario(@Param("idEmpleado") Integer idEmpleado, @Param("porcentaje") Double porcentaje);
}