package com.rayosoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Empleos2026Application {

	public static void main(String[] args) {
		SpringApplication.run(Empleos2026Application.class, args);
	}

}
