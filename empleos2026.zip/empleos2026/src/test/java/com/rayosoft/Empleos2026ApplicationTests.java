package com.rayosoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Empleos2026ApplicationTests {

	@Test
	void contextLoads() {
	}

}
